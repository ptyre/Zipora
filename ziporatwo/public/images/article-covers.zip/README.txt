A Pen created at CodePen.io. You can find this one at https://codepen.io/primalivet/pen/wNooNV.

 Portrait article covers with text on images. This uses grid and flexbox so be sure to view the pen in a browser that supports them.